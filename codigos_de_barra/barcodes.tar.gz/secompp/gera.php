<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<head>
<title></title>
</head>
<body>

<?php
for ($x = 0; $x <500 ; $x++)
{
	?><IMG SRC="barcode.php?barcode=<?php echo $x?>&width=160&height=50"> <br>
 <?
}
?>
</body>
</html>
